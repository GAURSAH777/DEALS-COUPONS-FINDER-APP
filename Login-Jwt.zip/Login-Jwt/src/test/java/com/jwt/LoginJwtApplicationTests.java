package com.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
