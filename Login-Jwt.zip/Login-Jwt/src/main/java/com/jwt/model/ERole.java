package com.jwt.model;

public enum ERole {
	ROLE_USER, ROLE_ADMIN
}
